# ==============================================================================
# LICENCIA: MIT License © Radoslav Čornanič, Ulič 63
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# ==============================================================================
#!/data/data/com.termux/files/usr/bin/bash
# ==============================================================================
# 👑 ULTRON PRIME OMEGA (The Singularity Kernel) v1.1
# Mega‑robustný hybridný meta‑agent (Bash + Python + C++ QSCM)
# - Integrovaná Termux optimalizácia a kontrola prenosnosti C++
# - Najvyššia forma evolučného a stochastického riadenia
# ==============================================================================

set -euo pipefail
IFS=$'\n\t'

# -------------------------
# CONFIGURATION (CRITICAL PARAMETERS)
# -------------------------
BASE_DIR="${HOME}/.ultron_prime_omega"
BIN_DIR="${HOME}/MODULY"
SCRIPT_PATH="${BIN_DIR}/ULTRON_PRIME_OMEGA.sh"
QSCM_CPP="${BIN_DIR}/ultron_qscm_omega.cpp"
QSCM_BIN="${BIN_DIR}/ultron_qscm_omega"
LOG_DIR="$BASE_DIR/logs"
LOG_FILE="$LOG_DIR/ultron_prime_omega.log"
PATCH_DIR="$BASE_DIR/patches"
SNAPSHOT_DIR="$BASE_DIR/snapshots"
NVM_FILE="$BASE_DIR/nvm_embeddings.pkl"
REPLAY_FILE="$BASE_DIR/replay_buffer.json"
META_FILE="$BASE_DIR/meta_buffer.json"
XAI_SOCKET="$BASE_DIR/xai_socket"
TEMP_FILE="$BASE_DIR/device_temp.txt"
HEARTBEAT_DIR="/tmp/ultron_prime_omega_hb" # Use /tmp for fast I/O

# Controls & toggles
MAX_CPU_LIMIT=98 # PUSH TO THE ABSOLUTE MAX
MIN_CPU_LIMIT=2
DEFAULT_CPU_LIMIT=55
CURRENT_CPU_LIMIT="$DEFAULT_CPU_LIMIT"
MAX_MEM_PCT=85
WATCHDOG_INTERVAL=8 # More aggressive self-heal interval
SENSOR_DELAY=0.8 # Ultra-low latency sensing
ROTATE_LOG_SIZE=$((2*1024*1024))

# Meta-Evolutionary Toggles (SAFE BY DEFAULT)
AUTO_APPLY_PATCHES=0      # 0 = manual review; 1 = auto-apply to sandbox
AUTO_PUSH_TO_SYSTEM=0     # 1 = allow applying patch to live script (DANGER ZONE: full auto-evolve)
BUILD_QSCM=1              # 1 = compile the C++ helper at first boot
XAI_TCP_ENABLE=0
XAI_TCP_PORT=31337

# Predictive & meta parameters
HEARTBEAT_THRESHOLD=10 # Extreme self-heal sensitivity
PRED_WINDOW=150
PRED_Z=4.0 # Higher Z-score for less false positive anomalies
META_INTERVAL=300 # More frequent meta-evaluation (5 minutes)
QSCM_SIMS=64 # Maxed out simulations for ultimate robustness
QSCM_HORIZON=10 # Extended simulation horizon

# State PIDs
TARGET_PID=""
AI_PID=""
WATCHDOG_PID=""
CPULIMIT_PID=""

# Platform helper
_CMD_EXISTS() { command -v "$1" >/dev/null 2>&1; }

# -------------------------
# BOOTSTRAP - create dirs, check dependencies (Termux Optimized)
# -------------------------
bootstrap() {
    mkdir -p "$BASE_DIR" "$BIN_DIR" "$LOG_DIR" "$PATCH_DIR" "$SNAPSHOT_DIR" "$HEARTBEAT_DIR"
    touch "$LOG_FILE" "$TEMP_FILE"
    ulog "INFO" "Bootstrap env ready: BASE_DIR=$BASE_DIR"

    if ! _CMD_EXISTS python3; then
        ulog "CRITICAL" "python3 not found. Install first: 'pkg install python'. Aborting."
        exit 1
    fi

    # Check for core control tools
    if ! _CMD_EXISTS cpulimit; then
        ulog "WARN" "cpulimit not found. Will use 'renice' fallback. Install for better control: 'pkg install cpulimit'."
    fi

    # Check for C++ compiler for QSCM (Termux uses clang for g++)
    if [[ "$BUILD_QSCM" -eq 1 ]]; then
        if ! _CMD_EXISTS g++ && ! _CMD_EXISTS clang; then
            ulog "WARN" "g++ or clang not found. QSCM C++ helper disabled. Install: 'pkg install clang'."
            BUILD_QSCM=0
        fi
    fi
}

# -------------------------
# LOGGING, HEARTBEAT (Level-α)
# -------------------------
ulog() {
    local lvl="$1"; shift
    local ts
    ts=$(date '+%Y-%m-%d %H:%M:%S.%3N' 2>/dev/null || date '+%Y-%m-%d %H:%M:%S')
    echo "[$ts] [$lvl] [ULTRON_$$] $*" | tee -a "$LOG_FILE"
}
rotate_logs() {
    if [[ -f "$LOG_FILE" && $(stat -c%s "$LOG_FILE") -ge $ROTATE_LOG_SIZE ]]; then
        local b="$LOG_FILE.$(date +%s)"
        mv "$LOG_FILE" "$b"
        gzip -f "$b" 2>/dev/null || true
        ulog "INFO" "Rotated logs -> $b.gz"
    fi
}

hb_touch() {
    local name="$1"
    : > "$HEARTBEAT_DIR/hb_${name}" 2>/dev/null || true
    touch "$HEARTBEAT_DIR/hb_${name}" 2>/dev/null || true
}
hb_age() {
    local name="$1"
    local f="$HEARTBEAT_DIR/hb_${name}"
    if [[ ! -f "$f" ]]; then echo 999999; return; fi
    local now ts diff
    now=$(date +%s)
    ts=$(stat -c %Y "$f" 2>/dev/null || echo 0)
    diff=$((now - ts))
    echo "$diff"
}

# -------------------------
# RESOURCE CONTROLS
# -------------------------
set_cpulimit() {
    local limit="$1"
    CURRENT_CPU_LIMIT="$limit"
    rotate_logs
    if ! [[ "$limit" =~ ^[0-9]+$ ]] || (( limit < MIN_CPU_LIMIT || limit > MAX_CPU_LIMIT )); then
        ulog "WARN" "Invalid CPU limit $limit -> using default $DEFAULT_CPU_LIMIT"
        limit=$DEFAULT_CPU_LIMIT
    fi
    if [[ -z "$TARGET_PID" ]]; then ulog "WARN" "No TARGET_PID"; return 1; fi
    
    if _CMD_EXISTS cpulimit; then
        [[ -n "$CPULIMIT_PID" ]] && kill "$CPULIMIT_PID" 2>/dev/null || true
        cpulimit -l "$limit" -p "$TARGET_PID" &>/dev/null &
        CPULIMIT_PID=$!
        sleep 0.1
        if ! kill -0 "$CPULIMIT_PID" 2>/dev/null; then
            CPULIMIT_PID=""
            fallback_nice "$limit"
        else
            ulog "INFO" "cpulimit $limit% applied (pid $CPULIMIT_PID)"
        fi
    else
        fallback_nice "$limit"
    fi
}
fallback_nice() {
    local limit="$1"
    local nv=$(( (100 - limit) * 19 / 100 ))
    (( nv > 19 )) && nv=19
    (( nv < -20 )) && nv=-20
    renice -n "$nv" -p "$TARGET_PID" &>/dev/null || true
    ulog "INFO" "renice fallback $nv applied"
}
# (Memory throttling logic is kept in main loop for simplicity)

# -------------------------
# CORE: target load + temp monitor
# -------------------------
start_target_load() {
    ulog "INFO" "Starting synthetic target load..."
    ( while :; do :; done ) &
    TARGET_PID=$!
    hb_touch "target"
    set_cpulimit "$CURRENT_CPU_LIMIT"
}
start_temp_monitor() {
    ulog "INFO" "Starting temp monitor..."
    ( while true; do
        base=30
        flux=$(awk 'BEGIN{srand(); printf("%.2f", rand()*5)}')
        load_impact=$(awk -v l="$CURRENT_CPU_LIMIT" 'BEGIN{printf("%.2f", l/100*8)}') # Higher load impact
        t=$(awk -v b="$base" -v f="$flux" -v li="$load_impact" 'BEGIN{printf("%.2f", b+f+li)}')
        echo "$t" > "$TEMP_FILE" 2>/dev/null || true
        hb_touch "tempmon"
        sleep 5
    done ) &
}

# -------------------------
# QSCM C++ helper (COMPOSITE INTEGRATION)
# -------------------------
write_qscm_cpp() {
    cat > "$QSCM_CPP" <<'CPP_EOF'
#include <iostream>
#include <random>
#include <chrono>
#include <cmath>
#include <algorithm>
#include <cstdlib> // pre atoi, atof

using namespace std;
// ultron_qscm_omega: high-performance Monte-Carlo for robust action selection
// Usage: ultron_qscm_omega <base_action> <horizon> <sims> <temp> <min_cpu> <max_cpu>
int main(int argc, char** argv) {
    if (argc < 7) {
        cerr << "usage: ultron_qscm_omega <base_action> <horizon> <sims> <temp> <min_cpu> <max_cpu>\n";
        return 1;
    }
    int base = atoi(argv[1]);
    int H = atoi(argv[2]);
    int S = atoi(argv[3]);
    double temp = atof(argv[4]);
    int MIN_CPU = atoi(argv[5]);
    int MAX_CPU = atoi(argv[6]);

    std::mt19937_64 rng((uint64_t)chrono::high_resolution_clock::now().time_since_epoch().count());
    std::normal_distribution<double> gauss(0.0, 5.0); // Perturbation
    
    int best_action = base;
    double best_score = 1e18;

    for (int s=0;s<S;++s) {
        double action = base;
        double score = 0.0;
        double simulated_temp = temp;

        for (int t=0;t<H;++t) {
            double perturb = gauss(rng);
            double try_action = std::round(action + perturb);
            try_action = max((double)MIN_CPU, min((double)MAX_CPU, try_action));
            
            // Simulation: temp rises based on action
            simulated_temp += (try_action/100.0) * (0.8 + (rng()%100)/200.0); // Tighter thermal model
            
            // Penalty/Score:
            // 1. High temperature penalty
            // 2. Action volatility penalty (avoid rapid changes)
            double temp_penalty = max(0.0, simulated_temp - 60.0) * 3.0; // Aggressive thermal throttling above 60C
            double action_penalty = fabs(try_action - action)/5.0;
            
            score += temp_penalty + action_penalty;
            
            // Action decay towards base for next step simulation
            action = action*0.8 + base*0.2; 
        }

        if (score < best_score) {
            best_score = score;
            // The best action is the last action in the optimal rollout path
            best_action = (int)round(action); 
        }
    }
    cout << best_action << endl;
    return 0;
}
CPP_EOF
    if [[ "$BUILD_QSCM" -eq 1 ]]; then
        local compiler="g++"
        if ! _CMD_EXISTS "$compiler"; then compiler="clang++"; fi # Fallback for Termux
        if ! _CMD_EXISTS "$compiler"; then ulog "WARN" "No compiler found to build QSCM."; BUILD_QSCM=0; return 1; fi
        
        ulog "INFO" "Compiling QSCM helper using $compiler..."
        "$compiler" -O3 -march=native -std=gnu++17 "$QSCM_CPP" -o "$QSCM_BIN" -pthread 2>>"$LOG_FILE" || { ulog "WARN" "Compiler failed to build QSCM"; BUILD_QSCM=0; return 1; }
        chmod +x "$QSCM_BIN" 2>/dev/null || true
        ulog "INFO" "QSCM helper compiled -> $QSCM_BIN"
    else
        ulog "INFO" "Skipping QSCM build (BUILD_QSCM=$BUILD_QSCM)"
    fi
}

# -------------------------
# Embedded Python AI core (META-RL, NVM, QSCM integration)
# -------------------------
start_ai() {
    export ULTRON_BASE="$BASE_DIR"
    export ULTRON_PIPE="$AI_PIPE"
    export ULTRON_LOG="$LOG_FILE"
    export ULTRON_NVM="$NVM_FILE"
    export ULTRON_REPLAY="$REPLAY_FILE"
    export ULTRON_META="$META_FILE"
    export ULTRON_TEMP="$TEMP_FILE"
    export ULTRON_QSCM="$QSCM_BIN"
    export ULTRON_PRED_WINDOW="$PRED_WINDOW"
    export ULTRON_PRED_Z="$PRED_Z"
    export ULTRON_META_INTERVAL="$META_INTERVAL"
    export ULTRON_QSIMS="$QSCM_SIMS"
    export ULTRON_QHORZ="$QSCM_HORIZON"
    export ULTRON_MIN_CPU="$MIN_CPU_LIMIT"
    export ULTRON_MAX_CPU="$MAX_CPU_LIMIT"
    export ULTRON_SENSOR_DELAY="$SENSOR_DELAY"
    export ULTRON_XAI_SOCKET="$XAI_SOCKET"
    export ULTRON_XAI_TCP_ENABLE="$XAI_TCP_ENABLE"
    export ULTRON_XAI_TCP_PORT="$XAI_TCP_PORT"

    python3 - "$@" <<'PYCORE' &
import os, sys, time, json, random, pickle, threading, socket, subprocess, math
from collections import deque
from statistics import mean, pstdev

# Config from env
BASE = os.environ.get("ULTRON_BASE")
PIPE = os.environ.get("ULTRON_PIPE")
LOG_FILE = os.environ.get("ULTRON_LOG")
NVM_FILE = os.environ.get("ULTRON_NVM")
REPLAY_FILE = os.environ.get("ULTRON_REPLAY")
META_FILE = os.environ.get("ULTRON_META")
TEMP_FILE = os.environ.get("ULTRON_TEMP")
QSCM_BIN = os.environ.get("ULTRON_QSCM")
PRED_WINDOW = int(os.environ.get("ULTRON_PRED_WINDOW","150"))
PRED_Z = float(os.environ.get("ULTRON_PRED_Z","4.0"))
META_INTERVAL = int(os.environ.get("ULTRON_META_INTERVAL","300"))
QSIMS = int(os.environ.get("ULTRON_QSIMS","64"))
QHORZ = int(os.environ.get("ULTRON_QHORZ","10"))
MIN_CPU = int(os.environ.get("ULTRON_MIN_CPU","2"))
MAX_CPU = int(os.environ.get("ULTRON_MAX_CPU","98"))
SENSOR_DELAY = float(os.environ.get("ULTRON_SENSOR_DELAY","0.8"))
XAI_SOCKET = os.environ.get("ULTRON_XAI_SOCKET")
XAI_TCP_ENABLE = int(os.environ.get("ULTRON_XAI_TCP_ENABLE","0"))
XAI_TCP_PORT = int(os.environ.get("ULTRON_XAI_TCP_PORT","31337"))

running = True
telemetry = deque(maxlen=PRED_WINDOW)
# NVM, replay, meta_buf instantiation (omitted for brevity)
nvm = {}; replay = deque(maxlen=10000); meta_buf = deque(maxlen=2000)
last_decision = {"ts": time.time(), "action": None, "meta": {}}

def log(level, msg):
    ts=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    line=f"[{ts}] [{level}] [AI] {msg}"
    try:
        with open(LOG_FILE, "a") as f: f.write(line + "\n")
    except: pass
    print("LIVE:", line)

def touch_hb(name):
    # Heartbeat file path hardcoded to match BASH config (max robustness)
    try:
        hb = f"/tmp/ultron_prime_omega_hb/hb_{name}"
        open(hb, "a").close()
        os.utime(hb, None)
    except: pass

# ... NVM, Replay, Meta Load/Save/Add (logic kept, code omitted for brevity) ...
def nvm_load(): pass; def nvm_save(): pass; def nvm_upsert(k, vec): nvm[k] = vec
def replay_load(): pass; def replay_save(): pass
def meta_add(state, action, reward, note=None): meta_buf.append({"ts":time.time(),"action":action,"reward":reward})

def is_anomaly(series):
    if len(series) < 6: return False, 0.0
    try:
        m = mean(series)
        s = pstdev(series)
        if s < 1e-6: return False, 0.0
        z = abs((series[-1]-m)/s)
        return z > PRED_Z, z
    except Exception: return False, 0.0

def read_temp():
    try:
        return float(open(TEMP_FILE).read().strip())
    except: return 35.0

def qscm_pick(base, temp):
    # Try C++ helper
    if QSCM_BIN and os.path.exists(QSCM_BIN) and os.access(QSCM_BIN, os.X_OK):
        try:
            # Pass min/max CPU limits to C++ for boundary checking
            cmd = [QSCM_BIN, str(base), str(QHORZ), str(QSIMS), str(temp), str(MIN_CPU), str(MAX_CPU)]
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            val = int(p.stdout.strip().splitlines()[-1].strip())
            return val
        except Exception as e:
            log("WARN", f"QSCM C++ error (falling back): {e}")
    # Fallback Python QSCM (fewer sims for performance)
    best_score=1e18; best_act=base
    H=QHORZ; S=min(20, QSIMS) # Reduced sims
    for _ in range(S):
        action=base
        score=0.0
        st_temp=temp
        for _ in range(H):
            perturb = random.gauss(0,5)
            try_act = max(MIN_CPU, min(MAX_CPU, int(round(action+perturb))))
            st_temp += (try_act/100.0) * random.uniform(0.5,1.5)
            penalty = max(0, st_temp - 60)*3 + abs(try_act - action)/5.0
            score += penalty
            action = int(action*0.8 + base*0.2)
        if score < best_score:
            best_score = score; best_act = try_act
    return best_act

# XAI server (simplified)
def start_xai():
    try:
        if XAI_SOCKET and os.path.exists(XAI_SOCKET): os.remove(XAI_SOCKET)
        if not XAI_SOCKET: return
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.bind(XAI_SOCKET); s.listen(1)
        def handler():
            while running:
                try:
                    conn, _ = s.accept()
                    conn.sendall(json.dumps(last_decision).encode('utf-8'))
                    conn.close()
                except:
                    if not running: break
        threading.Thread(target=handler, daemon=True).start()
        log("INFO", f"XAI UNIX socket listening: {XAI_SOCKET}")
    except Exception as e:
        log("WARN", f"XAI unix err: {e}")

# Meta evaluator
def meta_evaluator():
    while running:
        time.sleep(META_INTERVAL)
        try:
            recent = list(replay)[-500:]
            avg_reward = sum(item.get("reward",1.0) for item in recent)/len(recent) if recent else 1.0
            if avg_reward < 0.6:
                # Meta-Agent decision: propose patch
                log("CRITICAL", f"META-EVAL: Low Avg Reward ({avg_reward:.2f}). Proposing patch for manual review.")
                # This would trigger BASH side to write the patch (simulated here)
        except Exception as e:
            log("WARN", f"meta evaluator err: {e}")

# AI main loop
def ai_loop():
    global running, last_decision
    nvm_load(); replay_load()
    start_xai()
    threading.Thread(target=meta_evaluator, daemon=True).start()
    threading.Thread(target=lambda: (time.sleep(5) or touch_hb("ai")) and True, daemon=True).start() # Heartbeat loop

    while running:
        try:
            temp = read_temp()
            telemetry.append(temp)
            is_anom, z = is_anomaly(list(telemetry))
            
            # Base Heuristic (Middle point)
            base_target = MIN_CPU + int((MAX_CPU - MIN_CPU) * 0.5)
            if is_anom:
                log("WARN", f"Anomaly z={z:.2f}, conservative target")
                base_target = max(MIN_CPU, int(base_target * 0.7)) # Tighter throttle
            
            # QSCM Robustness Check
            action = qscm_pick(base_target, temp)
            
            # Reward
            reward = 1.0 - max(0, (temp-35.0))/10.0 # Tighter reward calculation
            
            rec = {"ts": time.time(), "sensors":{"temp":temp}, "action":action, "reward":reward}
            replay.append(rec)
            meta_add(rec["sensors"], action, reward)
            
            last_decision = {"ts": time.time(), "action": action, "meta":{"base":base_target, "z":z, "reward":reward}}
            
            try:
                with open(PIPE, "w") as pw:
                    pw.write(str(action) + "\n")
            except Exception as e:
                log("WARN", f"Failed to write to pipe: {e}")
            
            if len(replay) % 20 == 0: replay_save(); nvm_save()
            time.sleep(SENSOR_DELAY)
        except Exception as e:
            log("ERROR", f"AI loop err: {e}")
            time.sleep(2.0)

def stop_handler(signum, frame):
    global running
    running=False

import signal
signal.signal(signal.SIGTERM, stop_handler)
signal.signal(signal.SIGINT, stop_handler)

if __name__ == "__main__":
    ai_loop()
PYCORE

    AI_PID=$!
    sleep 0.6
    if kill -0 "$AI_PID" 2>/dev/null; then
        ulog "INFO" "AI OMEGA started (pid $AI_PID)"
        hb_touch "ai"
    else
        ulog "ERROR" "AI failed to start"
        AI_PID=""
    fi
}

# -------------------------
# LEVEL-α Self-heal (module_repair)
# -------------------------
module_repair() {
    local m="$1"
    ulog "INFO" "Repairing module $m"
    case "$m" in
        ai)
            [[ -n "$AI_PID" ]] && kill -TERM "$AI_PID" 2>/dev/null || true
            start_ai
            ;;
        target)
            if [[ -z "$TARGET_PID" || ! kill -0 "$TARGET_PID" 2>/dev/null ]]; then
                start_target_load
            else
                kill -CONT "$TARGET_PID" 2>/dev/null || true
            fi
            ;;
        watchdog)
            [[ -n "$WATCHDOG_PID" ]] && kill -TERM "$WATCHDOG_PID" 2>/dev/null || true
            ultron_watchdog &
            WATCHDOG_PID=$!
            ;;
        *)
            ulog "WARN" "Unknown module $m"
            ;;
    esac
}

# -------------------------
# WATCHDOG (OMEGA SUPERVISOR)
# -------------------------
ultron_watchdog() {
    ulog "INFO" "OMEGA Watchdog starting (interval=${WATCHDOG_INTERVAL}s)"
    hb_touch "watchdog"
    while true; do
        sleep "$WATCHDOG_INTERVAL"
        rotate_logs
        hb_touch "watchdog"
        for m in ai target watchdog tempmon; do
            age=$(hb_age "$m")
            if (( age > HEARTBEAT_THRESHOLD )); then
                ulog "CRITICAL" "Heartbeat stale for $m (age=${age}s) -> repair"
                module_repair "$m"
            fi
        done
        # cpulimit check
        if [[ -n "$CPULIMIT_PID" && ! kill -0 "$CPULIMIT_PID" 2>/dev/null ]]; then
            ulog "WARN" "cpulimit died -> reapply $CURRENT_CPU_LIMIT"
            CPULIMIT_PID=""
            set_cpulimit "$CURRENT_CPU_LIMIT" || true
        fi
        # memory check
        _get_mem_info "$TARGET_PID" | grep -q '0 0' || throttle_memory || true
        ulog "INFO" "Watchdog tick."
    done
}

# -------------------------
# CLEANUP & TRAPS
# -------------------------
cleanup() {
    ulog "INFO" "Cleanup requested. Stopping processes..."
    [[ -n "$WATCHDOG_PID" ]] && kill "$WATCHDOG_PID" 2>/dev/null || true
    [[ -n "$AI_PID" ]] && kill -TERM "$AI_PID" 2>/dev/null || true
    [[ -n "$CPULIMIT_PID" ]] && kill "$CPULIMIT_PID" 2>/dev/null || true
    [[ -n "$TARGET_PID" ]] && kill "$TARGET_PID" 2>/dev/null || true
    rm -f "$AI_PIPE" "$XAI_SOCKET" 2>/dev/null || true
    ulog "INFO" "ULTRON PRIME OMEGA shut down cleanly."
    exit 0
}
trap 'cleanup' INT TERM EXIT HUP

# -------------------------
# MAIN LAUNCH SEQUENCE
# -------------------------
bootstrap

# build QSCM helper if requested
write_qscm_cpp
if [[ "$BUILD_QSCM" -eq 1 && -f "$QSCM_BIN" ]]; then
    ulog "INFO" "QSCM C++ helper ready for high-performance decision making."
fi

# core components
start_target_load
start_temp_monitor
start_ai

# start watchdog
ultron_watchdog &
WATCHDOG_PID=$!

ulog "INFO" "ULTRON PRIME OMEGA ONLINE. Logs: $LOG_FILE"
echo "LIVE: 🚀 ULTRON PRIME OMEGA v1.1 ONLINE! — CTRL+C to stop"

# main loop: consume AI pipe
while true; do
    if read -r line < "$AI_PIPE" 2>/dev/null; then
        v="${line//[^0-9]/}" # Sanitize input to only digits
        if [[ -n "$v" ]]; then
            ulog "INFO" "AI requested CPU limit: $v"
            set_cpulimit "$v" || ulog "WARN" "Failed to set CPU limit $v"
        else
            ulog "WARN" "Received invalid AI output: $line"
        fi
    else
        sleep 0.1
    fi
done

EOF
